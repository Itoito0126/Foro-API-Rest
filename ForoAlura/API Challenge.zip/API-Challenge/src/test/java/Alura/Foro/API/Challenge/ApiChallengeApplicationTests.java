package Alura.Foro.API.Challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
