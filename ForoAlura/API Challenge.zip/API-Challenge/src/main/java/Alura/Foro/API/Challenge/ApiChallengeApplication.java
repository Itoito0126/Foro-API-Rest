package Alura.Foro.API.Challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiChallengeApplication.class, args);
	}

}
